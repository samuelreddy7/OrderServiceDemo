﻿using NSubstitute;
using OrderServiceDemo.Models.Exceptions;
using OrderServiceDemo.Services.Components;
using OrderServiceDemo.Services.Infrastructure;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace OrderServiceDemo.Unit.Tests.Services
{
    public class OrderServiceTests
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IOrderLineItemRepository _orderLineItemRepository;

        public OrderServiceTests()
        {
            _orderRepository = Substitute.For<IOrderRepository>();
            _orderLineItemRepository = Substitute.For<IOrderLineItemRepository>();
        }

        [Fact]
        public async Task OrderService_WhenCreatingOrder_IfNoLineItems_ThrowsInvalidRequestException()
        {
            //Arrange
            var order = new Models.Order();
            var service = BuildService();

            //Act && Assert
            var result = await Assert.ThrowsAsync<InvalidRequestException>(() => service.CreateOrder(order));
        }

        [Fact]
        public async Task OrderService_WhenCancellingOrder_IfInvalidOrder_ThrowsInvalidRequestException()
        {
            //Arrange
            var service = BuildService();

            //Act && Assert
            var result = await Assert.ThrowsAsync<InvalidRequestException>(() => service.CancelOrder(1));
        }

        [Fact]
        public async Task OrderService_WhenDeletingOrder_IfInvalidOrder_ThrowsInvalidRequestException()
        {
            //Arrange
            var service = BuildService();

            //Act && Assert
            var result = await Assert.ThrowsAsync<InvalidRequestException>(() => service.DeleteOrder(1));
        }

        [Fact]
        public async Task OrderService_WhenCancellingOrder_IfSuccess_ReturnOrder()
        {
            var order = new Models.Order()
            {
                UserId = 1,
                OrderId = 1,
                OrderStatusId = 1001,
                PurchasedOn = DateTime.Now,
                OrderLineItems = new List<Models.OrderLineItem>() { new Models.OrderLineItem() { OrderId = 1, ProductId = 1, Quantity = 1, ItemPrice = 8 } }
            };

            //Arrange
            _orderRepository.GetOrder(Arg.Any<int>()).Returns(order);
            _orderRepository.UpdateOrder(Arg.Any<Models.Order>()).Returns(order);

            var service = BuildService();

            //Act
            var result = await service.CancelOrder(1);

            //Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task OrderService_WhenCancellingOrder_IfOrderCancelled_ThrowsInvalidRequestException()
        {
            var order = new Models.Order()
            {
                UserId = 1,
                OrderId = 1,
                OrderStatusId = 1025,
                PurchasedOn = DateTime.Now,
                OrderLineItems = new List<Models.OrderLineItem>() { new Models.OrderLineItem() { OrderId = 1, ProductId = 1, Quantity = 1, ItemPrice = 8 } }
            };

            //Arrange
            _orderRepository.GetOrder(Arg.Any<int>()).Returns(order);
            var service = BuildService();

            //Act && Assert
            var result = await Assert.ThrowsAsync<InvalidRequestException>(() => service.CancelOrder(1));
        }

        [Fact]
        public async Task OrderService_WhenDeletingOrder_IfSuccess_ReturnOrder()
        {
            var order = new Models.Order()
            {
                UserId = 1,
                OrderId = 1,
                OrderStatusId = 1001,
                PurchasedOn = DateTime.Now,
                OrderLineItems = new List<Models.OrderLineItem>() { new Models.OrderLineItem() { OrderId = 1, ProductId = 1, Quantity = 1, ItemPrice = 8 } }
            };

            //Arrange
            _orderRepository.GetOrder(Arg.Any<int>()).Returns(order);
            _orderRepository.DeleteOrder(Arg.Any<Models.Order>()).Returns(order);
            _orderLineItemRepository.DeleteAllLineItemsInOrder(Arg.Any<int>()).Returns(order.OrderLineItems);

            var service = BuildService();

            //Act
            var result = await service.DeleteOrder(1);

            //Assert
            Assert.NotNull(result);
        }

        private OrderService BuildService() => new OrderService(
            _orderRepository,
            _orderLineItemRepository);
    }
}
